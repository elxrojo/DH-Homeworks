public class Main {
    public static void main(String[] args) {
        Seleccion s1 = new Seleccion("Argentina");
        s1.agregarJugador(new Jugador("DELANTERO","Messi", 10));
        s1.agregarJugador(new Jugador("DEFENSOR","Romero", 6));
        s1.agregarJugador(new Jugador("MEDIOCAMPISTA","Paredes", 5));
        s1.agregarJugador(new Jugador("Arquero","Martinez", 19));
        s1.obtenerReservas();


    }
}
